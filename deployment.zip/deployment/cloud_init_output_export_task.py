import boto3
import collections
import time
from datetime import datetime, timedelta

region = 'eu-west-2'

log_name = '/connectivity_tester/cloud-init/output'
destination_s3_bucket = 's3-dq-log-archive-bucket-preprod'
destination_prefix = 'logs-dq-ec2-cloud-init-output'

one_day = datetime.now() - timedelta(days=1)
last_24_hours = int(round(one_day.timestamp() * 10000))
now = int(round(time.time() * 1000))

def lambda_handler(event, context):

    s3 = boto3.client('logs')

    response = s3.create_export_task(
        logGroupName=log_name,
        fromTime=last_24_hours,
        to=now,
        destination=destination_s3_bucket,
        destinationPrefix=destination_prefix
    )
